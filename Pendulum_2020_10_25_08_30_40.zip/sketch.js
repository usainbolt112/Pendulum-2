 
function preload(){
  class bob
     this.image = loadImage("bob.jpg");
  }
    
  class roof
     this.image = loadImage("sprites/wood1.png");
  }
  

}  
function setup() {
  createCanvas(400, 400);
class bob=createClass{
  constructor(x,y){
    super(x,y,50,50);}
  class roof=createClass{
  constructor(x, y, width, height){
    super(x,y,width,height);
 
}

function draw() {
  background(220);
  
roof1 = new roof(100,200,40,40);
  bob1 = new roof(120,200,40,40);
  bob2 = new roof(140,200,40,40);
  bobo3 = new roof(160,200,40,40);
  bob4 = new roof(180,200,40,40);
  bob5 = new roof(200,200,40,40);
}